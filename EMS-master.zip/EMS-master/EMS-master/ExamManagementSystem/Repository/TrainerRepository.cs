﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseContexts;
using Models;
using Models.SearchCriteria;

namespace Repository
{
    public class TrainerRepository
    {
        ExamManagementDbContext db = new ExamManagementDbContext();
        
        //Get All Organization
        public List<Organization> GetAllOrgnization()
        {
            List<Organization> organizations = db.Organizations.Where(c => c.IsDeleted == false).ToList();
            return organizations;
        }


        //Get Courses Againts Organization
        public List<Course> GetCourseByOrganizationId(int id)
        {
            var course = db.Courses.Where(c => c.OrganizationId == id && c.IsDeleted == false).ToList();
            return course;
        }

        //Add Trainer
        public bool Add(Trainer trainer)
        {
            db.Trainers.Add(trainer);

            return db.SaveChanges() > 0;
        }

        //Get All Trainers
        public List<Trainer> GetTrainerBySearch(TrainerSearchCriteria criteria)
        {
            IQueryable<Trainer> trainers = db.Trainers.Where(c => c.IsDeleted == false).AsQueryable();

            if (!string.IsNullOrEmpty(criteria.Name))
            {
                trainers = trainers.Where(c => c.Name.ToLower().Contains(criteria.Name.ToLower()));
            }

            if (criteria.OrganizationId > 0)
            {
                trainers = trainers.Where(c =>
                    c.OrganizationId.ToString().Contains(criteria.OrganizationId.ToString()));
            }

            if (criteria.CourseId > 0)
            {
                trainers = trainers.Where(c => c.CourseId.ToString().Contains(criteria.CourseId.ToString()));
            }

            if (criteria.CountryId > 0)
            {
                trainers = trainers.Where(c => c.CountryId.ToString().Contains(criteria.CountryId.ToString()));
            }

            if (criteria.CityId > 0)
            {
                trainers = trainers.Where(c => c.CityId.ToString().Contains(criteria.CityId.ToString()));
            }

            if (!string.IsNullOrEmpty(criteria.Email))
            {
                trainers = trainers.Where(c => c.Email.ToLower().Contains(criteria.Email.ToLower()));
            }


            return trainers.ToList();
        }


        //Get Trainer By Id
        public Trainer GetById(int id)
        {
            var data = db.Trainers.Where(c => c.Id == id).FirstOrDefault();
            return data;
        }

        //Update Trainer
        public bool Update(Trainer trainer)
        {
            db.Entry(trainer).State = EntityState.Modified;
            return db.SaveChanges() > 0;
        }

        //Delete Trainer
        public bool Delete(int id)
        {
            Trainer trainer = new Trainer();
            trainer = db.Trainers.Where(c => c.Id == id).FirstOrDefault();

            if (trainer != null)
            {
                trainer.IsDeleted = true;
                return Update(trainer);
            }

            return false;
        }

        //Get Batch Againts Course
        public List<Batch> GetBatchByCourseId(int id)
        {
            var batch = db.Batches.Where(c => c.CourseId == id && c.IsDeleted == false).ToList();
            return batch;
        }

        //Get All Countries
        public List<Country> GetAllCountries()
        {
            List<Country> countries = db.Countries.ToList();
            return countries;
        }

        //Get city Againts COuntries
        public List<City> GetCitiesByCountry(int id)
        {
            var cities = db.Cities.Where(c => c.CountryId == id).ToList();
            return cities;
        }




    }
}
